//
// Created by os on 7/29/23.
//

#ifndef OS_PROJECT_PRINT_HPP
#define OS_PROJECT_PRINT_HPP

#include "../lib/hw.h"

extern void printString1(char const *string);
extern void printInteger1(uint64 integer);
//extern void printStringForUserMode(char const *string);

#endif //OS_PROJECT_PRINT_HPP
