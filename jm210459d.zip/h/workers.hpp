//
// Created by os on 7/29/23.
//

#ifndef OS_PROJECT_WORKERS_HPP
#define OS_PROJECT_WORKERS_HPP

extern void workerBodyA();
extern void workerBodyB();
extern void workerBodyC(void*);
extern void workerBodyD(void*);

#endif //OS_PROJECT_WORKERS_HPP
